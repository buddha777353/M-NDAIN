public class NewDate {
    int date;
}
