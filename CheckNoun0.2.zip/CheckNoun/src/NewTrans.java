public class NewTrans {
    int trans;
}
