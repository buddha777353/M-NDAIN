import javafx.event.ActionEvent;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.util.Scanner;
public class Main {

    //fields

    public Double newAmt = null;
    public String newDesc = null;
    public int newTransNum;
    public int newDate;


    public static void main(String[] args) {

        //declarations
        JLabel introText = new JLabel();

        JTextField amt = new JTextField();
        JTextField desc = new JFormattedTextField();
        JTextField transNum = new JFormattedTextField();
        JTextField date = new JFormattedTextField();

        JFrame dasFrame = new JFrame("New Entry");
        JPanel panel = new JPanel();

        //JTextField settings
        amt.setColumns(30);
        desc.setColumns(30);
        transNum.setColumns(30);
        date.setColumns(30);
        introText.setText("New Entry:");
        amt.setText("Amount");
        desc.setText("Description");
        transNum.setText("Check/Transaction Number");
        date.setText("DDMMYY");

        //adding TextFields
        panel.add(amt);
        panel.add(desc);
        panel.add(transNum);
        panel.add(date);

        //Panel settings
        panel.setBackground(Color.GREEN);

        //adding Panel
        dasFrame.add(panel);

        //Frame settings
        dasFrame.setVisible(true);
        dasFrame.setSize(500,500);
    }

    // button thing to submit Textfield data to FileWriter.
    //  WIP
    public void actionPerformed(ActionEvent clickEnter) {

    }

    //FileReader goes here
    static {


    }

}
//read coma separated values