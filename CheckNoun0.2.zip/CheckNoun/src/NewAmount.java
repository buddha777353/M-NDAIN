public class NewAmount {
    Double amount;

}
