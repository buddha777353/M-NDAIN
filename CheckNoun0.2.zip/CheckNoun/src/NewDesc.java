public class NewDesc {
    String desc;
}
